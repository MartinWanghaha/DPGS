////////////////////////////////////////////////////////////////////////////  
// Copyright 2023-2024 3D Vision Group at the State Key Lab of CAD&CG,   
// Zhejiang University. All Rights Reserved.  
//  
// For more information see <https://github.com/zju3dv/PGSR>  
// If you use this software, please cite the corresponding publications    
// listed on the above website.  
//  
// Permission to use, copy, modify and distribute this software and its  
// documentation for educational, research and non-profit purposes only.  
// Any modification based on this work must be open-source and prohibited  
// for commercial use.  
// You must retain, in the source form of any derivative works that you  
// distribute, all copyright, patent, trademark, and attribution notices  
// from the source form of this work.  
//   
// For commercial uses of this software, please send email to zhangguofeng@zju.edu.cn  
////////////////////////////////////////////////////////////////////////////